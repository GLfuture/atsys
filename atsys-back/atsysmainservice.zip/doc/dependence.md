# dependence

spdlog

nlohmann/json

yaml-cpp

cpp-jwt

libmysqlclient

hiredis

cpp-jwt

grpc

protobuffer

openssl(version > 1.1.0 , exchange grpc default boringssl to openssl)