# callback

#### 自定义callback

不使用init_callback接口，改为自己实现global_callback