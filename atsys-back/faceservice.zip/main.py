# 0. 导入模块
import json
import os
from io import BytesIO
import jwt

import dlib
import glob
import numpy as np
import http.server

from skimage import io

secret_key = 'token-secret-180580'
token_algorithm = 'HS256'

# 1. 加载模型、图片

# 正向人脸检测器
detector = dlib.get_frontal_face_detector()
# 加载特征点提取模型
predictor_path = "E:\\Pycharm-Project\\atsys\\shape_predictor_68_face_landmarks.dat"
predictor = dlib.shape_predictor(predictor_path)
# 加载面部识别模型
face_rec_model_path = "E:\\Pycharm-Project\\atsys\\dlib_face_recognition_resnet_model_v1.dat"
facerec = dlib.face_recognition_model_v1(face_rec_model_path)
# 已知图片
known_image_path = "E:\\Pycharm-Project\\atsys\\know\\"
# 测试图片
test_image_path = "E:\\Pycharm-Project\\atsys\\unknow\\"

# 声明descriptors，用于存放已知图片对应的人脸特征向量
uids = []
descriptors = []


def compute_face_descriptor_from_bytes(image_bytes):
    t_img = io.imread(BytesIO(image_bytes))
    detections = detector(t_img)
    if len(detections) > 0:
        t_shape = predictor(t_img, detections[0])
        return facerec.compute_face_descriptor(t_img, t_shape)
    return None


# 遍历known_image_path文件夹下所有以.jpg结尾的文件。
for f in glob.glob(os.path.join(known_image_path, "*.jpg")):
    img = dlib.load_rgb_image(f)
    # 使用 detector 检测器来检测图像中的人脸
    dets = detector(img, 1)
    for k, d in enumerate(dets):
        # 获取人脸特征点
        shape = predictor(img, d)
        # 计算特征向量
        face_descriptor = facerec.compute_face_descriptor(img, shape)
        # 特征向量转换为numpy array
        v = np.array(face_descriptor)
        # 把此次数据存到人脸特征向量列表里面
        descriptors.append(v)
        uids.append(int(f[len(known_image_path):f.rfind('.')]))


class MyHandler(http.server.BaseHTTPRequestHandler):
    def do_POST(self):
        # 设置响应头
        if self.path != "/api/face":
            self.send_response(404)
            return
        token = jwt.decode(self.headers['Token'], secret_key, token_algorithm)
        self.send_response(200)
        self.send_header('Content-Type', 'text/plain')
        self.end_headers()
        body = self.rfile.read(int(self.headers['Content-Length']))
        face_descriptor = compute_face_descriptor_from_bytes(body)
        t_data = {}
        if face_descriptor is None:
            self.wfile.write(json.dumps({"code": -1}).encode())
        for indx, descriptor in enumerate(descriptors):
            distance = np.linalg.norm(descriptor - np.array(face_descriptor))
            if distance < 0.4:
                t_data['code'] = -1
                if int(token['uid']) == uids[indx]:
                    t_data['code'] = 0
                break
            else:
                t_data['code'] = -1
        json_string = json.dumps(t_data)
        print(json_string.encode('utf-8'))
        self.send_header('Content-Length', len(json_string))
        # 发送响应体
        self.wfile.write(json_string.encode())


# 4. 进行判断
httpd = http.server.HTTPServer(('localhost', 8080), MyHandler)

httpd.serve_forever()
